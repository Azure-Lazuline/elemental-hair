# boki-colors

![](https://github.com/Azure-Lazuline/boki-colors/blob/main/screenshots/boki.png?raw=true)

Changes Lea to have palettes based on Boki. The four elements get swapped to four of Boki's alternate weapon colors too.

### Installation

To use, install [ccloader](https://github.com/CCDirectLink/CCLoader), and go to the "Mods" menu ingame (the button at the *top* of the Options menu, not the tab on the right) and it should be listed there to select and install. It should automatically grab any prerequisites.

You can also install manually by placing [the .ccmod file](https://github.com/Azure-Lazuline/boki-colors/releases) in your ccloader mods folder, as well as [elemental-hair](https://github.com/Azure-Lazuline/elemental-hair/releases) since that's what handles recoloring Lea.
