{
	elementalhair.AddAsset("media/entity/npc/triblader-lea.png", "triblader-lea-colors.png");
	elementalhair.AddAsset("media/entity/npc/triblader-lea.png ", "triblader-lea-colors.png"); //account for a typo in some anim definitions ^^
	elementalhair.AddAsset("media/entity/npc/triblader-lea-extra.png", "triblader-lea-colors.png");
}